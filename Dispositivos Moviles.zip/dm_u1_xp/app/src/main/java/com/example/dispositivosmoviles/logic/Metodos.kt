package com.example.dispositivosmoviles.logic

class Metodos {

    fun suma(a: Int, b:Int):Int = a+b

}