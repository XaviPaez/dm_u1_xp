package com.example.dispositivosmoviles.data.entities

data class LoginUser (val name:String = "root", val pass:String ="root") {



}